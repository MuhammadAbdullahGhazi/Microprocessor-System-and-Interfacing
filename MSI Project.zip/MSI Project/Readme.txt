The basic idea for the project came from the hologram technology. 
It is a three-dimensional projection which can be seen without using special type of lenses or glasses. 
Basically, in hologram technology there is only a projection of light from different angels which make a 3D image. 
But we are developing a hologram on lower level which is hardware based.

Propeller display is a special type of circular display that project an image as if the images are floating in the air. 
This project was started with a simple principle which is frequently happening in our day today life, which is Persistence of Vision (POV). 
Whenever the light from an image strikes on the retina, the eye retains the impression of that light for a particular fraction of seconds (1/16th) depending on the brightness of the image even after the image has been removed from the human sight. 

Work:
The display features 24 x RGB LEDs, provides a flicker free image to the human eye and is powerful enough to display and manipulate simple 3D meshes in real time. 
Also included are timing mechanisms to drive a clock and synchronization mechanisms to keep the image stable independent of the motor speed